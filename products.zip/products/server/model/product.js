var mong=require('mongoose');


const productSchema=new mong.Schema({


    productName:{
        type:String,
        required:false
    },
    productPrice:{
        type:Number,    
        required:false
    }
  
});

const prods=module.exports=mong.model('prods',productSchema)