var express = require('express')
var router=express.Router();
var prods=require('../model/product')

//=====================================================add

router.post("/prod",(req,res,next)=>{
    let ipProd=new prods({
        productName:req.body.productName,
        productPrice:req.body.productPrice,
        
    });

  ipProd.save((err,data)=>{
    if(err){
        res.send(err)
    }
    else
    res.send('data iserted')
  })
})


//==========================================================get
router.get("/prod",(req,res,next)=>{

    prods.find((err,prod)=>{
        if(err){
            res.json(err)
        }
        else{
            res.json(prod)

        }
    })

});

//=======================================================================delete

router.delete("/prod/:id",(req,res,next)=>{

    prods.remove({_id:req.params.id},
    
        (err,prod)=>{
    if(err){
        res.json(err)
    }
    else{
        res.json(prod)
    }
})

});

//======================================================================update
router.get("/prod:id",(req,res,next)=>{

    prods.findById(req.params.id,(err,prod)=>{
        if(err){
            res.json(err)
        }
        else{

            res.json(prod)
            console.log(prod)
        }
    })

});



router.put("/prod/:id",(req,res,next)=>{
    prods.findByIdAndUpdate(req.params.id,req.body,
        (err,prod)=>{
      
    if(err){
        res.json(err)
    }
    else{
        res.json("edited")
      
    }
})
 }); 



module.exports=router;