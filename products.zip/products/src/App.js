import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import AddProduct from './components/addProduct'
import GetProducts from './components/getProducts'


class App extends Component {
  render() {
    return (
      <div className="App">
     <AddProduct/>
     <GetProducts/>
      </div>
    );
  }
}

export default App;
