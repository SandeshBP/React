import React, { Component } from 'react';
import axios from 'axios'

class GetProducts extends Component {
    constructor(props){
        super(props)
        
    }
     baseurl='http://localhost:2000/api/prod'
    state={product:{
      productName:'',
           productPrice:'',
           
       },
       id:'',
       products:[]
      }
    
//======================================================================
    getAllProducts=()=>{
        console.log(this.state.products)

        axios.get(this.baseurl).then(response => {
            console.log(this.state.products)

          this.setState({ products: response.data });
          console.log(this.state.products)
        })
      }
//==============================================================================
deleteProduct(id){
axios.delete(this.baseurl+'/'+id).then(response=>{
  this.getAllProducts()
})
}
//=============================================================================
UpdateProduct(id){
 this.setState({id:id})

  // axios.get(this.baseurl+'/'+id).then(response=>{
   
  //   this.setState({product:response.value})
  // })
  console.log(this.state.id)
}

onChangeState=(ctrl,value)=>{
  const {product}=this.state
  product[ctrl]=value
  this.setState({product
  })


}
onSubmit=(e)=>{
  e.preventDefault()
  axios.put(this.baseurl+'/'+this.state.id,this.state.product).then(response=>{
    this.getAllProducts()

  })
}



//==============================================================================
componentDidMount(){
    this.getAllProducts()
}
//===============================================================================
  render() {
    return (
      <div >
        <br/>
        <br/>
        <br/>
        <br/>

        <div className='col-lg-4'>
        <h2>Product List</h2>
          <table className='table table-bordred'>
          <thead>
          <tr>
              <th>ProductName</th>
              <th>ProductPrice</th>

          </tr>
          </thead>
         
              {this.state.products.map((prod)=> <tbody>
          <tr>
              <td>{prod.productName}</td>
              <td>{prod.productPrice}
              <button className='btn btn-danger' onClick={(e)=>this.deleteProduct(prod._id)}>X</button>
              <button className='btn btn-danger' onClick={(e)=>this.UpdateProduct(prod._id)}>Edit</button>
                </td>
          </tr>
              </tbody>
            )}
        
          </table>
          </div>
          <div className='col-lg-3'>    
          <br/>
        <br/>
        <br/>   
             <h3>Update Product</h3>


          <form onSubmit={this.onSubmit}>
                <div className="form-group">
                    <label>Product Name:  </label>
                    <input type="text" className="form-control" value={this.state.productName} 
                    onChange={(e)=>this.onChangeState('productName',e.currentTarget.value)}/>
                </div>
                <div className="form-group">
                    <label>Product Price: </label>
                    <input type="text" className="form-control" value={this.state.productPrice} 
                     onChange={(e)=>this.onChangeState('productPrice',e.currentTarget.value)}/>
                </div>
                <div className="form-group">
                    <input type="submit" value="Add Node server" className="btn btn-primary"/>
                </div>
            </form>
            </div>
     
      </div>
    );
  }
}

export default GetProducts;
