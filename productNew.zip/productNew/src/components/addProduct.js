import React, { Component } from 'react';
import axios from 'axios'

class AddProduct extends Component {
    constructor(props){
        super(props)
      this.state={product:{
       productName:'sfsfsfsf',
            productPrice:''
        }}
    } 
     

    onChangeState=(ctrl,value)=>{
      const {product}=this.state
      product[ctrl]=value
      this.setState({product
      })


    }
onSubmit=(e)=>{
e.preventDefault()
  console.log(this.state.product)
  axios.post('http://localhost:2000/api/prod',this.state.product).then(responce=>{
   
  })
}
    

    //===========================================================================
  render() {
    return (
      <div>
          <div className='col-lg-4'>
               <h3>Add Product</h3>

          <form onSubmit={this.onSubmit}>
                <div className="form-group">
                    <label>Product Name:  </label>
                    <input type="text" className="form-control" value={this.state.productName} 
                    onChange={(e)=>this.onChangeState('productName',e.currentTarget.value)}/>
                </div>
                <div className="form-group">
                    <label>Product Price: </label>
                    <input type="text" className="form-control" value={this.state.productPrice} 
                     onChange={(e)=>this.onChangeState('productPrice',e.currentTarget.value)}/>
                </div>
                <div className="form-group">
                    <input type="submit" value="Add Product" className="btn btn-primary"/>
                </div>
            </form>
            </div>
      </div>
    );
  }
}

export default AddProduct;
